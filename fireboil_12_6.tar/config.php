<?php
		define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', 'farttt');
    define('DB_DATABASE', 'fireboil_db');
?>
